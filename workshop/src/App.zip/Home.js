import React from "react";
function Home(){
    return (
        <>
            <h2>This is the Home component</h2>
            <h3>It is the next line to render</h3>
        </>
    )
}
export {Home}