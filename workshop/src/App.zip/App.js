// import Mainpage from "./landingpage/Mainpage";
import React from "react";
import Navsec from "./landingpage/Navsec";
import Baner from "./landingpage/Baner";
import Footer from "./landingpage/Footer";
import Content from "./landingpage/Content";
import About from "./landingpage/About";
import Portfolio from "./landingpage/Portfolio";
import Contact from "./landingpage/Contact";
import { BrowserRouter as Router,Route, Routes } from "react-router-dom";
function  App(){
  return (
    <Router>
    {/* <Mainpage/> */}
    {/* <Accordion/> */}
    <Navsec/>
    <Baner/>
    <Routes>
      <Route path="/" element={<Content/>}></Route>
      <Route path="/about" element={<About/>}></Route>
      <Route path="/Portfolio" element={<Portfolio/>}></Route>
      <Route path="/contact" element={<Contact/>}></Route>
    </Routes>
    <Footer/>
  </Router>
  );
}
export default App;